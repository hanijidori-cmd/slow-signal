"use client";

import Link from "next/link";

const STEPS = ["발견", "선택", "지도", "도착"];

export default function Header({ currentStep }: { currentStep?: number }) {
  return (
    <>
      <div className="top-bar">
        <Link href="/" className="brand" style={{ textDecoration: "none", color: "inherit" }}>
          🌿 슬로우-시그널
        </Link>
        <div className="nav-links">
          <Link href="/how-to">❓ 이용안내</Link>
          <Link href="/">🏠 홈</Link>
        </div>
      </div>
      {currentStep !== undefined && (
        <div className="step-indicator">
          {STEPS.map((label, idx) => (
            <div key={label} style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <div style={{ textAlign: "center" }}>
                <div
                  className={
                    "dot " +
                    (idx < currentStep ? "done" : idx === currentStep ? "active" : "")
                  }
                >
                  {idx < currentStep ? "✓" : idx + 1}
                </div>
                <div className="label">{label}</div>
              </div>
              {idx < STEPS.length - 1 && <div className="line" />}
            </div>
          ))}
        </div>
      )}
    </>
  );
}
