"use client";

import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Header from "@/components/Header";
import { getReviews, addReview, ReviewPost } from "@/lib/clientState";

type PoiDetail = {
  title: string | null;
  overview: string | null;
  firstImage: string | null;
  usetime: string | null;
  restdate: string | null;
  parking: string | null;
  infocenter: string | null;
  audioGuide: { title: string | null; audioUrl: string | null } | null;
};

export default function PoiDetailPage({ params }: { params: { contentId: string } }) {
  return (
    <Suspense fallback={<div className="card">불러오는 중...</div>}>
      <PoiDetailContent params={params} />
    </Suspense>
  );
}

function PoiDetailContent({ params }: { params: { contentId: string } }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const mapX = searchParams.get("mapX");
  const mapY = searchParams.get("mapY");

  const [data, setData] = useState<PoiDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [reviews, setReviews] = useState<ReviewPost[]>([]);
  const [reviewText, setReviewText] = useState("");
  const [speaking, setSpeaking] = useState(false);

  useEffect(() => {
    setLoading(true);
    setError(null);
    const qs = mapX && mapY ? `?mapX=${mapX}&mapY=${mapY}` : "";
    fetch(`/api/poi/${params.contentId}${qs}`)
      .then((res) => res.json())
      .then((json) => {
        if (json.error) throw new Error(json.error);
        setData(json);
        if (json.title) setReviews(getReviews(json.title));
      })
      .catch(() => setError("공공데이터를 불러오지 못했어요."))
      .finally(() => setLoading(false));
  }, [params.contentId, mapX, mapY]);

  const readOverviewAloud = () => {
    if (!data?.overview || typeof window === "undefined" || !("speechSynthesis" in window)) return;
    const utter = new SpeechSynthesisUtterance(data.overview);
    utter.lang = "ko-KR";
    setSpeaking(true);
    utter.onend = () => setSpeaking(false);
    window.speechSynthesis.speak(utter);
  };

  const submitReview = () => {
    if (!data?.title || !reviewText.trim()) return;
    addReview(data.title, reviewText.trim());
    setReviews(getReviews(data.title));
    setReviewText("");
  };

  return (
    <div>
      <Header currentStep={1} />

      <div className="card" style={{ background: "#eef6f3", border: "1px solid var(--color-primary)" }}>
        <div style={{ fontSize: 12, fontWeight: 700, color: "var(--color-primary-dark)" }}>
          🏛️ 한국관광공사 공공데이터 연계 정보
        </div>
      </div>

      {loading && <div className="card">불러오는 중...</div>}

      {error && (
        <div className="card">
          {error}
          <button className="btn btn-outline" style={{ marginTop: 12 }} onClick={() => window.location.reload()}>
            다시 시도
          </button>
        </div>
      )}

      {data && !error && (
        <>
          {data.firstImage && (
            <div className="image-block">
              <img src={data.firstImage} alt={data.title ?? ""} />
            </div>
          )}
          <div className="card" style={{ marginTop: -8 }}>
            <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 8 }}>{data.title}</div>
            {data.overview && (
              <p style={{ fontSize: 13, color: "var(--color-text-muted)", lineHeight: 1.6 }}>{data.overview}</p>
            )}

            <div className="grid-2" style={{ marginTop: 12, marginBottom: 12 }}>
              <div className="stat-box"><div className="label">이용시간</div><div className="value">{data.usetime || "정보 없음"}</div></div>
              <div className="stat-box"><div className="label">쉬는날</div><div className="value">{data.restdate || "정보 없음"}</div></div>
              <div className="stat-box"><div className="label">주차</div><div className="value">{data.parking || "정보 없음"}</div></div>
              <div className="stat-box"><div className="label">문의</div><div className="value">{data.infocenter || "정보 없음"}</div></div>
            </div>

            {data.audioGuide ? (
              <button className="btn btn-outline">🎧 {data.audioGuide.title ?? "오디오 가이드"} 재생</button>
            ) : (
              <button className="btn btn-outline" onClick={readOverviewAloud} disabled={speaking}>
                {speaking ? "🔊 읽어주는 중..." : "🔊 텍스트로 듣기"}
              </button>
            )}
          </div>

          <div className="card">
            <div className="section-title" style={{ margin: "0 0 10px" }}>이 곳 후기 ({reviews.length})</div>
            {reviews.slice(0, 5).map((r) => (
              <div key={r.id} className="review-item">
                {r.content}
                <div className="meta">익명 · {new Date(r.createdAt).toLocaleDateString("ko-KR")}</div>
              </div>
            ))}
            {reviews.length === 0 && <div style={{ fontSize: 12, color: "var(--color-text-muted)" }}>아직 후기가 없어요.</div>}
          </div>

          <div className="btn-row">
            <button className="btn btn-primary" onClick={() => router.push("/map")}>
              여기로 결정, 길찾기 보기 →
            </button>
          </div>
        </>
      )}

      <div className="api-label">사용 API: KorService2 detailCommon2/detailIntro2/detailImage2 · Odii(또는 overview TTS 대체)</div>
    </div>
  );
}
