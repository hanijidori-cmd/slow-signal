"use client";

import { useEffect, useState } from "react";
import Header from "@/components/Header";
import {
  getTripState,
  setTripState,
  TripState,
  appendCheckInLog,
  addReview,
} from "@/lib/clientState";

const CARBON_FACTOR_KG_PER_KM = 0.12;

function generateCouponCode(seed: string) {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) hash = (hash * 31 + seed.charCodeAt(i)) % 999999;
  return `SLOW-${String(hash).padStart(6, "0")}`;
}

export default function ArrivalPage() {
  const [trip, setTrip] = useState<TripState | null>(null);
  const [reviewText, setReviewText] = useState("");
  const [reviewSubmitted, setReviewSubmitted] = useState(false);

  useEffect(() => {
    const current = getTripState();
    const distance = current.selectedCandidate?.distanceKm ?? 0;
    const points = Math.round(distance * 5);
    const badgeName = "남도 슬로우러 배지";
    const badges = current.badges ?? [];
    const nextBadges = badges.includes(badgeName) ? badges : [...badges, badgeName];
    const nextPoints = (current.totalPoints ?? 0) + points;
    const updated = setTripState({ badges: nextBadges, totalPoints: nextPoints });
    setTrip(updated ?? current);

    if (typeof window !== "undefined" && current.selectedCandidate) {
      const entryType = (window.localStorage.getItem("slow-signal-entry-type") as "congestion" | "discovery") ?? "congestion";
      const carbon = Math.round(distance * CARBON_FACTOR_KG_PER_KM * 100) / 100;
      appendCheckInLog({
        id: `${Date.now()}`,
        destinationName: current.destinationName ?? "",
        candidateTitle: current.selectedCandidate.title,
        regionName: current.selectedCandidate.regionName,
        distanceKm: distance,
        carbonKg: carbon,
        points,
        couponCode: generateCouponCode(current.selectedCandidate.contentId),
        entryType,
        createdAt: new Date().toISOString(),
      });
    }
  }, []);

  if (!trip) return <div className="card">불러오는 중...</div>;

  const distance = trip.selectedCandidate?.distanceKm ?? 0;
  const carbon = Math.round(distance * CARBON_FACTOR_KG_PER_KM * 100) / 100;
  const regionName = trip.selectedCandidate?.regionName ?? "우회지";
  const candidateTitle = trip.selectedCandidate?.title ?? "";
  const couponCode = generateCouponCode(trip.selectedCandidate?.contentId ?? "demo");
  const estConsumption = Math.round(distance * 400 + 30000); // 데모용 추정 소비효과(원)

  const shareText = `남도 슬로우 여정을 완주했어요! ${candidateTitle}로 우회해서 탄소 ${carbon}kg을 절감하고 지역쿠폰을 받았습니다. #슬로우시그널 #전남여행`;

  const shareViaKakao = () => {
    if (navigator.share) {
      navigator.share({ title: "슬로우-시그널", text: shareText }).catch(() => {});
    } else {
      navigator.clipboard?.writeText(shareText);
      alert("공유 텍스트가 복사되었습니다. 카카오톡에 붙여넣어 공유해보세요.");
    }
  };

  const submitReview = () => {
    if (!reviewText.trim() || !candidateTitle) return;
    addReview(candidateTitle, reviewText.trim());
    setReviewText("");
    setReviewSubmitted(true);
  };

  return (
    <div>
      <Header currentStep={3} />

      <div className="card" style={{ textAlign: "center" }}>
        <div style={{ fontSize: 12, color: "var(--color-text-muted)", marginBottom: 10 }}>
          덕분에 {trip.destinationName}의 혼잡을 피하고, {regionName}에 {estConsumption.toLocaleString()}원의 소비효과를 만들었어요
        </div>
        <div style={{ width: 56, height: 56, borderRadius: "50%", background: "#e6f3ef", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 10px", fontSize: 24 }}>🌿</div>
        <div style={{ fontWeight: 700, marginBottom: 4 }}>도착 완료! 🎉</div>
        <div style={{ fontSize: 12, color: "var(--color-text-muted)", marginBottom: 14 }}>{candidateTitle} · {regionName}</div>

        <div className="grid-2" style={{ textAlign: "left" }}>
          <div className="stat-box"><div className="label">탄소절감(kg)</div><div className="value">{carbon}</div></div>
          <div className="stat-box"><div className="label">가치포인트</div><div className="value">{Math.round(distance * 5)}</div></div>
          <div className="stat-box"><div className="label">예상 소비효과(원)</div><div className="value">{estConsumption.toLocaleString()}</div></div>
          <div className="stat-box"><div className="label">지역쿠폰 코드</div><div className="value" style={{ fontSize: 11 }}>{couponCode}</div></div>
        </div>
      </div>

      <div className="card" style={{ background: "linear-gradient(135deg, #fff9db, #fff3b0)", border: "1.5px dashed #c9a600" }}>
        <div style={{ fontSize: 12, fontWeight: 700, color: "#6b5900", marginBottom: 8 }}>💛 쿠폰 사용 방법</div>
        <div style={{ fontSize: 12, color: "#6b5900", marginBottom: 10 }}>
          {regionName} 소상공인 가맹점 결제 시 제시하면 5,000원 할인 또는 2배 적립 혜택을 받을 수
          있습니다.
        </div>
        <div className="btn-row" style={{ margin: 0 }}>
          <button className="btn btn-outline" onClick={() => alert("이 기능은 카카오같이가치 공식 파트너십 체결 후 지원됩니다.")}>
            💳 카카오페이 지갑
          </button>
          <button className="btn btn-outline" onClick={() => alert("영수증 예시입니다 (MVP 시연용).")}>
            🧾 영수증 보기
          </button>
        </div>
        <div style={{ fontSize: 10, color: "#9c8a3a", marginTop: 8 }}>
          ※ MVP 시연용 시뮬레이션이며, 실제 정산 연동은 사업 제휴 이후 적용됩니다.
        </div>
      </div>

      <div className="card">
        <div className="section-title" style={{ margin: "0 0 10px" }}>✏️ 이 곳 후기 남기기</div>
        {reviewSubmitted ? (
          <div style={{ fontSize: 12, color: "var(--color-primary)" }}>후기가 등록되었습니다. 감사합니다!</div>
        ) : (
          <>
            <textarea
              value={reviewText}
              onChange={(e) => setReviewText(e.target.value.slice(0, 200))}
              placeholder="한적했던 풍경, 맛있었던 식당, 좋았던 점을 남겨주세요 (최대 200자)"
              style={{ width: "100%", minHeight: 70, padding: 10, borderRadius: 10, border: "1px solid var(--color-border)", fontSize: 13, marginBottom: 8, fontFamily: "inherit" }}
            />
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span style={{ fontSize: 11, color: "var(--color-text-muted)" }}>{reviewText.length}/200자 · 익명 작성</span>
              <button className="btn btn-primary" style={{ width: "auto", padding: "8px 20px" }} onClick={submitReview}>
                등록
              </button>
            </div>
          </>
        )}
      </div>

      <div className="btn-row">
        <button className="btn btn-accent" onClick={shareViaKakao}>카카오톡으로 공유하기</button>
      </div>
      <div className="btn-row">
        <a className="btn btn-outline" href="/">🏠 홈으로</a>
      </div>

      <div style={{ fontSize: 11, color: "var(--color-text-muted)", textAlign: "center", marginBottom: 12 }}>
        ✓ 체크인 이력이 저장되었습니다 (익명 세션)
      </div>

      <div className="api-label">
        사용 API: 체크인 이력(localStorage) · 탄소절감=거리×0.12kg · 포인트=거리×5 · 쿠폰코드=해시 기반 생성
      </div>
    </div>
  );
}
