"use client";

import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Header from "@/components/Header";
import { DESTINATIONS } from "@/lib/destinations";
import { getTripState, setTripState } from "@/lib/clientState";

type Candidate = {
  contentId: string;
  title: string;
  mapX: number;
  mapY: number;
  regionName: string;
  distanceKm: number;
  sim: number;
  eff: number;
  score: number;
  firstImage: string | null;
};

export default function RouteSelectPage() {
  return (
    <Suspense fallback={<div className="card">불러오는 중...</div>}>
      <RouteSelectContent />
    </Suspense>
  );
}

function RouteSelectContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const isDiscovery = searchParams.get("mode") === "discovery";

  const [loading, setLoading] = useState(true);
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [noResultReason, setNoResultReason] = useState<string | null>(null);

  const trip = getTripState();
  const dest = DESTINATIONS.find((d) => d.id === trip.destinationId) ?? DESTINATIONS[0];

  useEffect(() => {
    const params = new URLSearchParams({
      destLat: String(dest.lat),
      destLng: String(dest.lng),
      destKeyword: dest.keyword,
    });

    fetch(`/api/recommend?${params.toString()}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.error) throw new Error(data.error);
        setCandidates(data.candidates ?? []);
        setNoResultReason(data.noResultReason ?? null);
      })
      .catch((err) => {
        console.error(err);
        setError("추천 우회지를 불러오지 못했습니다. 잠시 후 다시 시도해주세요.");
      })
      .finally(() => setLoading(false));
  }, [dest]);

  const selectCandidate = (c: Candidate) => {
    setTripState({
      selectedCandidate: {
        contentId: c.contentId,
        title: c.title,
        mapX: c.mapX,
        mapY: c.mapY,
        distanceKm: c.distanceKm,
        score: c.score,
        regionName: c.regionName,
      },
    });
    setTripState({ badges: getTripState().badges ?? [] }); // ensure init
    if (typeof window !== "undefined") {
      window.localStorage.setItem("slow-signal-entry-type", isDiscovery ? "discovery" : "congestion");
    }
    router.push("/map");
  };

  return (
    <div>
      <Header currentStep={1} />

      <div className={isDiscovery ? "card card-accent" : "card"}>
        <div style={{ fontWeight: 700, marginBottom: 4 }}>
          {isDiscovery ? "✨ 이런 곳은 어때요?" : "⚠️ 혼잡 우회 제안"}
        </div>
        <div style={{ fontSize: 12, color: "var(--color-text-muted)" }}>
          {isDiscovery
            ? "전남 인구감소지역의 숨겨진 명소를 발견해보세요. 한적하고 특별한 여행이 기다립니다."
            : `${dest.name} → 인구감소지역 우회 관광지`}
        </div>
      </div>

      <div className="card" style={{ background: "#eef2ee" }}>
        <div style={{ fontSize: 12, fontWeight: 600 }}>
          {isDiscovery ? "🍃 취향 발견" : "🎯 취향 발견"} — 취향 유사도(Sim) × 이동 효율(Eff) 스코어 기반 추천
        </div>
      </div>

      <div className="section-title">인구감소지역 추천 우회지 — 점수순</div>

      {loading && <div className="card">추천 우회지를 찾는 중...</div>}
      {error && <div className="card">{error}</div>}

      {!loading && !error && candidates.length === 0 && (
        <div className="card">{noResultReason ?? "조건을 만족하는 우회지가 없습니다."}</div>
      )}

      {candidates.map((c, idx) => (
        <div key={c.contentId} className={idx === 0 ? "card card-accent" : "card"}>
          {c.firstImage && (
            <div className="image-block" style={{ height: 110, marginBottom: 10 }}>
              <img src={c.firstImage} alt={c.title} />
            </div>
          )}
          <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 6 }}>
            <span className="badge">{idx + 1}</span>
            <span style={{ fontSize: 11, color: "var(--color-text-muted)" }}>{c.regionName}</span>
          </div>
          <div style={{ fontWeight: 700, marginBottom: 8 }}>{c.title}</div>

          <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 8 }}>
            <span className="badge">📏 {c.distanceKm}km</span>
            <span className="badge badge-accent">Sim {c.sim.toFixed(2)}</span>
            <span className="badge badge-accent">Eff {c.eff.toFixed(2)}</span>
          </div>

          <div style={{ marginBottom: 12 }}>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "var(--color-text-muted)", marginBottom: 3 }}>
              <span>종합점수</span>
              <span>{c.score.toFixed(2)}</span>
            </div>
            <div className="progress-bar-track">
              <div className="progress-bar-fill" style={{ width: `${c.score * 100}%` }} />
            </div>
          </div>

          <div className="btn-row" style={{ margin: 0 }}>
            <button className="btn btn-outline" onClick={() => router.push(`/poi/${c.contentId}?mapX=${c.mapX}&mapY=${c.mapY}`)}>
              세부정보
            </button>
            <button className="btn btn-primary" onClick={() => selectCandidate(c)}>
              여기로 갈게요
            </button>
          </div>
        </div>
      ))}

      {!isDiscovery && (
        <div className="btn-row">
          <button className="btn btn-outline" onClick={() => router.push("/")}>
            ✕ 홈으로 돌아가기
          </button>
        </div>
      )}

      <div className="api-label">
        사용 API: 한국관광공사 OpenAPI(KorService2/areaBasedList2) · Sim/Eff 스코어링(cat3 분류 + Haversine 거리)
      </div>
    </div>
  );
}
