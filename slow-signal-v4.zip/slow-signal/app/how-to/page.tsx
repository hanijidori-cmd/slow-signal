import Header from "@/components/Header";

export default function HowToPage() {
  return (
    <div>
      <Header />
      <div style={{ padding: "0 16px", marginBottom: 12 }}>
        <div style={{ fontSize: 20, fontWeight: 700 }}>이용안내</div>
        <div style={{ fontSize: 12, color: "var(--color-text-muted)" }}>
          슬로우-시그널이 무엇이고, 어떻게 쓰는지
        </div>
      </div>

      <div className="card">
        <div style={{ fontWeight: 700, marginBottom: 6 }}>🧭 슬로우-시그널이 하는 일</div>
        <div style={{ fontSize: 13, color: "var(--color-text-muted)", lineHeight: 1.6 }}>
          전남 인기 관광지가 혼잡할 때, 대신 가볍게 들를 수 있는 인구감소지역의 숨겨진 명소를
          안내합니다. 우회지를 방문하면 탄소절감·포인트·지역쿠폰으로 보상하며, 여행 관광지와
          지역 경제에 함께 도움이 된다는 것이 이 서비스의 목표입니다.
        </div>
      </div>

      <div className="card">
        <div style={{ fontWeight: 700, marginBottom: 6 }}>📊 혼잡도는 어떻게 계산되나요?</div>
        <div style={{ fontSize: 13, color: "var(--color-text-muted)", lineHeight: 1.6 }}>
          카카오모빌리티의 실시간 소요시간 데이터로 지금 얼마나 걸리는지 확인합니다. 이 값을
          평소 기준(시속 75km 가정 시 소요시간)과 비교해서, 15% 이상 더 걸리면 &quot;혼잡&quot;으로
          판단합니다. 보조로 한국도로공사 실시간 소통데이터도 함께 확인해 신뢰도를 보완합니다.
        </div>
      </div>

      <div className="card">
        <div style={{ fontWeight: 700, marginBottom: 6 }}>🗺️ 우회지는 어떻게 추천되나요?</div>
        <div style={{ fontSize: 13, color: "var(--color-text-muted)", lineHeight: 1.6 }}>
          두 가지를 함께 고려해 점수를 매깁니다. 첫째, 원래 목적지와 비슷한 성격의 장소인지
          (취향 유사도). 둘째, 너무 멀지 않은지(이동 효율, 20km 이내만 후보). 점수가 높은 순으로
          추천되며, &quot;🍃 새로운 곳 발견하기&quot;도 같은 기준으로 추천되지만 혼잡 여부와 상관없이
          언제든 이용할 수 있습니다.
        </div>
      </div>

      <div className="card">
        <div style={{ fontWeight: 700, marginBottom: 6 }}>🎁 방문하면 뭘 받나요?</div>
        <div style={{ fontSize: 13, color: "var(--color-text-muted)", lineHeight: 1.6 }}>
          우회지에 도착해 체크인하면 세 가지 보상이 적립됩니다. <b>탄소절감량</b>(우회거리 ×
          0.12kg으로 계산), <b>가치포인트</b>(우회거리 × 5로 적립, 마이여정에서 누적 확인), <b>지역쿠폰</b>
          (방문지역 쿠폰 코드 발급, 사용법은 파트너 매장에서 제시).
        </div>
      </div>

      <div className="card" style={{ background: "#fdf6ec" }}>
        <div style={{ fontWeight: 700, marginBottom: 6 }}>🙏 이 서비스가 할 수 없는 것</div>
        <div style={{ fontSize: 13, color: "var(--color-text-muted)", lineHeight: 1.6 }}>
          정직하게 말씀드리면, 지금 단계(MVP 시연)에서 실제 결제나 쿠폰 정산은 시뮬레이션입니다.
          또한 카카오내비 화면 안에 직접 뜨는 오버레이 기능은 아직 없으며, 별도 웹 서비스로 열어서
          사용하는 형태입니다. 실제 길안내는 카카오맵/카카오내비 앱으로 연결됩니다.
        </div>
      </div>

      <div className="btn-row">
        <a className="btn btn-primary" href="/">출발 전 혼잡 확인하기 →</a>
      </div>
    </div>
  );
}
