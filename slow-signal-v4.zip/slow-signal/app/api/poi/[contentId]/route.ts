import { NextRequest, NextResponse } from "next/server";

const KTO_API_KEY = process.env.KTO_SERVICE_KEY;
const KOR_BASE = "https://apis.data.go.kr/B551011/KorService2";
const ODII_BASE = "https://apis.data.go.kr/B551011/Odii";

async function fetchItem(url: string) {
  const res = await fetch(url, { next: { revalidate: 0 } });
  if (!res.ok) throw new Error(`API 호출 실패: ${res.status}`);
  const data = await res.json();
  return data?.response?.body?.items?.item ?? null;
}

export async function GET(
  req: NextRequest,
  { params }: { params: { contentId: string } }
) {
  const contentId = params.contentId;
  const { searchParams } = new URL(req.url);
  const mapX = searchParams.get("mapX");
  const mapY = searchParams.get("mapY");

  if (!contentId) {
    return NextResponse.json({ error: "contentId가 없습니다." }, { status: 400 });
  }
  if (!KTO_API_KEY) {
    return NextResponse.json({ error: "KTO_SERVICE_KEY가 설정되지 않았습니다." }, { status: 500 });
  }

  try {
    const [commonRaw, introRaw, imagesRaw] = await Promise.all([
      fetchItem(`${KOR_BASE}/detailCommon2?serviceKey=${KTO_API_KEY}&MobileOS=ETC&MobileApp=SlowSignal&contentId=${contentId}&defaultYN=Y&firstImageYN=Y&areacodeYN=Y&overviewYN=Y&_type=json`),
      fetchItem(`${KOR_BASE}/detailIntro2?serviceKey=${KTO_API_KEY}&MobileOS=ETC&MobileApp=SlowSignal&contentId=${contentId}&contentTypeId=12&_type=json`),
      fetchItem(`${KOR_BASE}/detailImage2?serviceKey=${KTO_API_KEY}&MobileOS=ETC&MobileApp=SlowSignal&contentId=${contentId}&imageYN=Y&_type=json`),
    ]);

    const c = Array.isArray(commonRaw) ? commonRaw[0] : commonRaw;
    const i = Array.isArray(introRaw) ? introRaw[0] : introRaw;
    const imgs = Array.isArray(imagesRaw) ? imagesRaw : imagesRaw ? [imagesRaw] : [];

    if (!c) {
      return NextResponse.json({ error: "해당 관광지 정보를 찾을 수 없습니다." }, { status: 404 });
    }

    // Odii 오디오 가이드 — 반경 5km, 없으면 null (프론트에서 overview TTS로 대체)
    let audioGuide: any = null;
    if (mapX && mapY) {
      try {
        const odiiUrl = `${ODII_BASE}/themeLocationBasedList?serviceKey=${KTO_API_KEY}&MobileOS=ETC&MobileApp=SlowSignal&mapX=${mapX}&mapY=${mapY}&radius=5000&numOfRows=1&pageNo=1&_type=json`;
        const odiiRes = await fetch(odiiUrl, { next: { revalidate: 0 } });
        if (odiiRes.ok) {
          const odiiData = await odiiRes.json();
          const odiiItem = odiiData?.response?.body?.items?.item;
          const first = Array.isArray(odiiItem) ? odiiItem[0] : odiiItem;
          if (first) {
            audioGuide = {
              title: first.title ?? first.themeName ?? null,
              audioUrl: first.audioUrl ?? first.audioTitle ?? null,
              raw: first, // 필드명 미검증 상태라 원본도 같이 반환 — 프론트에서 존재 여부만 판단에 사용
            };
          }
        }
      } catch (err) {
        console.error("Odii API 호출 실패(overview TTS로 대체):", err);
      }
    }

    return NextResponse.json({
      contentId,
      title: c.title ?? null,
      addr1: c.addr1 ?? null,
      addr2: c.addr2 ?? null,
      mapX: c.mapx ?? null,
      mapY: c.mapy ?? null,
      firstImage: c.firstimage || c.firstimage2 || null,
      overview: c.overview ?? null,
      tel: c.tel ?? null,
      homepage: c.homepage ?? null,
      usetime: i?.usetime ?? null,
      restdate: i?.restdate ?? null,
      parking: i?.parking ?? null,
      infocenter: i?.infocenter ?? null,
      chkpet: i?.chkpet ?? null,
      subImages: imgs.map((img: any) => ({ original: img.originimgurl, small: img.smallimageurl })),
      audioGuide,
    });
  } catch (err) {
    console.error("POI 상세 조회 실패:", err);
    return NextResponse.json({ error: "공공데이터 API 호출 중 오류가 발생했습니다. 잠시 후 다시 시도해주세요." }, { status: 502 });
  }
}
