import { NextRequest, NextResponse } from "next/server";
import { CONGESTED_HOTSPOTS } from "@/lib/candidates";
import {
  congestionFromKakaoDuration,
  congestionFromExData,
  fallbackCongestionIndex,
  timeOfDayBonus,
  hotspotBonus,
  ExVdsRecord,
  BASELINE_SPEED_KMH,
  CONGESTION_THRESHOLD_RATIO,
} from "@/lib/congestion";

// 서울 시청 근사 기본 출발지 (실제로는 프론트에서 사용자 위치 전달)
const DEFAULT_ORIGIN = { lat: 37.5665, lng: 126.978 };

const KAKAO_REST_KEY = process.env.KAKAO_REST_KEY;
const EX_API_KEY = process.env.EX_API_KEY;

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const destName = searchParams.get("destName") || "";
  const destLat = parseFloat(searchParams.get("destLat") || "");
  const destLng = parseFloat(searchParams.get("destLng") || "");
  const routeName = searchParams.get("routeName");
  const originLat = parseFloat(searchParams.get("originLat") || "") || DEFAULT_ORIGIN.lat;
  const originLng = parseFloat(searchParams.get("originLng") || "") || DEFAULT_ORIGIN.lng;

  // 1차: 카카오모빌리티 자동차 길찾기 (실시간 소요시간 기반, 주 데이터)
  if (KAKAO_REST_KEY && !Number.isNaN(destLat) && !Number.isNaN(destLng)) {
    try {
      const url =
        `https://apis-navi.kakaomobility.com/v1/directions?` +
        `origin=${originLng},${originLat}&destination=${destLng},${destLat}` +
        `&priority=RECOMMEND&summary=true`;
      const res = await fetch(url, {
        headers: { Authorization: `KakaoAK ${KAKAO_REST_KEY}` },
        next: { revalidate: 0 },
      });

      if (res.ok) {
        const data = await res.json();
        const route = data?.routes?.[0];
        if (route?.result_code === 0) {
          const duration = route.summary.duration; // 초
          const distance = route.summary.distance; // 미터
          const { delayRatio, congestionIndex } = congestionFromKakaoDuration(duration, distance);

          return NextResponse.json({
            source: "kakao_mobility",
            congestionIndex,
            isCongested: congestionIndex >= 60,
            durationSec: duration,
            distanceM: distance,
            delayRatio,
            baselineSpeedKmh: BASELINE_SPEED_KMH,
            thresholdRatio: CONGESTION_THRESHOLD_RATIO,
            breakdown: null,
            exError: null,
          });
        }
      } else if (res.status === 401 || res.status === 403) {
        console.error("카카오모빌리티 API 권한 필요 — developers.kakaomobility.com에서 신청 필요");
      }
    } catch (err) {
      console.error("카카오모빌리티 API 호출 실패:", err);
    }
  }

  // 2차 fallback: 한국도로공사 실시간 소통 데이터 + 시간대 보정
  let exWeight = 0;
  let exError: string | null = null;
  let sample: ExVdsRecord[] = [];

  if (EX_API_KEY) {
    try {
      const url = `https://data.ex.co.kr/openapi/odtraffic/trafficAmountByRealtime?key=${EX_API_KEY}&type=json`;
      const res = await fetch(url, { next: { revalidate: 0 } });
      if (!res.ok) throw new Error(`EX API 응답 오류: ${res.status}`);
      const data = await res.json();
      const list: ExVdsRecord[] = data?.list ?? data?.response?.body?.items ?? [];
      const filtered = routeName ? list.filter((r) => r.routeName?.includes(routeName)) : list;
      sample = filtered.slice(0, 5);
      exWeight = congestionFromExData(filtered);
    } catch (err) {
      console.error("한국도로공사 API 호출 실패:", err);
      exError = "실시간 도로 데이터를 불러오지 못해 시간대 기반 보정만 적용됩니다.";
    }
  } else {
    exError = "보조 데이터(한국도로공사) 키가 설정되지 않았습니다.";
  }

  const timeBonus = timeOfDayBonus();
  const hotspot = hotspotBonus(destName, CONGESTED_HOTSPOTS);
  const congestionIndex = fallbackCongestionIndex({ exWeight, timeBonus, hotspot });

  return NextResponse.json({
    source: "highway_corp_fallback",
    congestionIndex,
    isCongested: congestionIndex >= 60,
    breakdown: { exWeight, timeBonus, hotspot },
    exError,
    sample,
  });
}
