import { NextRequest, NextResponse } from "next/server";
import { CANDIDATE_REGIONS } from "@/lib/candidates";
import { simScore, effScore, totalScore, distanceTo } from "@/lib/scoring";

const KTO_API_KEY = process.env.KTO_SERVICE_KEY;
const KOR_SERVICE = "https://apis.data.go.kr/B551011/KorService2";
const TAR_RLTE_SERVICE = "https://apis.data.go.kr/B551011/TarRlteTarService1";
const MAX_DISTANCE_KM = 20; // ⚠️ 하드 필터 — 이 거리를 넘는 후보는 아예 응답에서 제외

async function fetchDestinationCategory(keyword: string): Promise<string | null> {
  if (!KTO_API_KEY) return null;
  try {
    const url = `${TAR_RLTE_SERVICE}/searchKeyword1?serviceKey=${KTO_API_KEY}&MobileOS=ETC&MobileApp=SlowSignal&keyword=${encodeURIComponent(keyword)}&numOfRows=1&pageNo=1&_type=json`;
    const res = await fetch(url, { next: { revalidate: 0 } });
    if (!res.ok) return null;
    const data = await res.json();
    const item = data?.response?.body?.items?.item;
    const first = Array.isArray(item) ? item[0] : item;
    return first?.rlteCtgryMclsNm ?? null;
  } catch (err) {
    console.error("연관관광지 API 조회 실패(카테고리 생략):", err);
    return null;
  }
}

type CandidatePlace = {
  contentId: string;
  title: string;
  mapX: number;
  mapY: number;
  category: string | null;
  firstImage: string | null;
};

async function fetchCandidatesInRegion(areaCode: string, sigunguCode: string): Promise<CandidatePlace[]> {
  if (!KTO_API_KEY) return [];
  try {
    const url = `${KOR_SERVICE}/areaBasedList2?serviceKey=${KTO_API_KEY}&MobileOS=ETC&MobileApp=SlowSignal&areaCode=${areaCode}&sigunguCode=${sigunguCode}&contentTypeId=12&numOfRows=10&pageNo=1&arrange=Q&_type=json`;
    const res = await fetch(url, { next: { revalidate: 0 } });
    if (!res.ok) return [];
    const data = await res.json();
    const items = data?.response?.body?.items?.item ?? [];
    const list = Array.isArray(items) ? items : [items];
    return list
      .filter((it: any) => it?.mapx && it?.mapy)
      .map((it: any) => ({
        contentId: it.contentid,
        title: it.title,
        mapX: parseFloat(it.mapx),
        mapY: parseFloat(it.mapy),
        category: it.cat3 ?? null,
        firstImage: it.firstimage || it.firstimage2 || null,
      }));
  } catch (err) {
    console.error(`후보지 조회 실패 (지역코드 ${sigunguCode}):`, err);
    return [];
  }
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const destLat = parseFloat(searchParams.get("destLat") || "");
  const destLng = parseFloat(searchParams.get("destLng") || "");
  const destKeyword = searchParams.get("destKeyword") || "";

  if (Number.isNaN(destLat) || Number.isNaN(destLng)) {
    return NextResponse.json({ error: "destLat, destLng 파라미터가 필요합니다." }, { status: 400 });
  }

  const destCategory = await fetchDestinationCategory(destKeyword);

  const regionResults = await Promise.all(
    CANDIDATE_REGIONS.map((region) =>
      fetchCandidatesInRegion(region.areaCode, region.sigunguCode).then((places) => ({ region, places }))
    )
  );

  const scored = regionResults.flatMap(({ region, places }) =>
    places
      .map((p) => {
        const distanceKm = distanceTo(destLat, destLng, p.mapY, p.mapX);
        return { p, region, distanceKm };
      })
      // ⚠️ 20km 초과 후보는 여기서 완전히 제거 (필터), 점수 계산 전에 걸러냄
      .filter(({ distanceKm }) => distanceKm <= MAX_DISTANCE_KM)
      .map(({ p, region, distanceKm }) => {
        const sim = simScore(destCategory, p.category);
        const eff = effScore(distanceKm, MAX_DISTANCE_KM);
        const score = totalScore(sim, eff);
        return {
          contentId: p.contentId,
          title: p.title,
          mapX: p.mapX,
          mapY: p.mapY,
          firstImage: p.firstImage,
          regionName: region.name,
          distanceKm: Math.round(distanceKm * 10) / 10,
          sim,
          eff,
          score,
        };
      })
  );

  const top3 = scored.sort((a, b) => b.score - a.score).slice(0, 3);

  return NextResponse.json({
    destCategory,
    destCategoryNote: "연관관광지API 기반 과거(2024.5~2025.4) 이동패턴 카테고리 — 실시간 취향분석 아님",
    maxDistanceKm: MAX_DISTANCE_KM,
    candidates: top3,
    noResultReason: top3.length === 0 ? `${MAX_DISTANCE_KM}km 이내 조건을 만족하는 우회지가 없습니다.` : null,
  });
}
