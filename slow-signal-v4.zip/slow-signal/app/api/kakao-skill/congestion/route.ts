import { NextRequest, NextResponse } from "next/server";
import { DESTINATIONS } from "@/lib/destinations";
import { congestionFromKakaoDuration } from "@/lib/congestion";

const KAKAO_REST_KEY = process.env.KAKAO_REST_KEY;
const DEFAULT_ORIGIN = { lat: 37.5665, lng: 126.978 }; // 서울 근사 기본 출발지

// 카카오 i 오픈빌더 스킬 표준 응답 형식으로 감싸는 헬퍼
function skillText(text: string, quickReplies?: string[]) {
  return NextResponse.json({
    version: "2.0",
    template: {
      outputs: [{ simpleText: { text } }],
      ...(quickReplies && quickReplies.length > 0
        ? {
            quickReplies: quickReplies.map((label) => ({
              label,
              action: "message",
              messageText: label,
            })),
          }
        : {}),
    },
  });
}

function findDestination(utterance: string) {
  return DESTINATIONS.find(
    (d) => utterance.includes(d.name) || utterance.includes(d.keyword)
  );
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const utterance: string = body?.userRequest?.utterance ?? "";

    const destination = findDestination(utterance);

    if (!destination) {
      // 목적지를 못 찾으면 안내 + 빠른 선택 버튼(퀵리플라이) 제공
      return skillText(
        "안녕하세요! 슬로우-시그널 봇이에요 🌿\n" +
          "전남 여행 목적지를 말씀해주시면, 실시간 혼잡과 숨은 우회지를 추천해드릴게요.\n\n" +
          "예: '이번 주말 여수 어때?'",
        DESTINATIONS.slice(0, 4).map((d) => `${d.name} 어때?`)
      );
    }

    // 카카오모빌리티 실시간 길찾기로 혼잡 판정 (웹앱과 동일 로직)
    if (KAKAO_REST_KEY) {
      try {
        const url =
          `https://apis-navi.kakaomobility.com/v1/directions?` +
          `origin=${DEFAULT_ORIGIN.lng},${DEFAULT_ORIGIN.lat}&destination=${destination.lng},${destination.lat}` +
          `&priority=RECOMMEND&summary=true`;
        const res = await fetch(url, {
          headers: { Authorization: `KakaoAK ${KAKAO_REST_KEY}` },
        });
        if (res.ok) {
          const data = await res.json();
          const route = data?.routes?.[0];
          if (route?.result_code === 0) {
            const duration = route.summary.duration;
            const distance = route.summary.distance;
            const { congestionIndex } = congestionFromKakaoDuration(duration, distance);
            const minutes = Math.round(duration / 60);
            const isCongested = congestionIndex >= 60;

            const message = isCongested
              ? `⚠️ ${destination.name} 방면, 지금 혼잡지수 ${congestionIndex}/100이에요.\n` +
                `지금 가면 약 ${minutes}분 걸려요. 인구감소지역 우회지를 추천해드릴까요?\n\n` +
                `자세히 보기: ${process.env.NEXT_PUBLIC_SITE_URL ?? ""}/route-select`
              : `✅ ${destination.name} 방면, 지금 혼잡지수 ${congestionIndex}/100로 원활해요.\n` +
                `약 ${minutes}분이면 도착하실 수 있어요. 편안한 여행 되세요!`;

            return skillText(message, ["다른 목적지 확인하기"]);
          }
        }
      } catch (err) {
        console.error("카카오모빌리티 스킬 호출 실패:", err);
      }
    }

    return skillText(
      `${destination.name} 혼잡 정보를 지금은 확인하지 못했어요. 잠시 후 다시 시도해주세요.`
    );
  } catch (err) {
    console.error("카카오 스킬 처리 실패:", err);
    return skillText("일시적인 오류가 발생했어요. 잠시 후 다시 시도해주세요.");
  }
}
