"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Header from "@/components/Header";
import { DESTINATIONS } from "@/lib/destinations";
import { setTripState } from "@/lib/clientState";

const CALC_STEPS = [
  "카카오모빌리티 실시간 경로 조회 중",
  "평소 대비 지연비율 계산 중",
  "보조 데이터(한국도로공사) 확인 중",
  "혼잡지수 산출 완료",
];

const DEST_EMOJI: Record<string, string> = {
  "yeosu-odongdo": "🌺",
  "suncheon-bay": "🦢",
  "damyang-juknokwon": "🎋",
  "wando-beach": "🏖️",
  "mokpo-yudalsan": "⛰️",
  "boseong-daehandawon": "🍃",
};

export default function HomePage() {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [destId, setDestId] = useState(DESTINATIONS[0].id);
  const [loading, setLoading] = useState(false);
  const [stepIndex, setStepIndex] = useState(-1);
  const [result, setResult] = useState<any>(null);

  const filtered = useMemo(() => {
    if (!query.trim()) return DESTINATIONS;
    return DESTINATIONS.filter((d) => d.name.includes(query) || d.keyword.includes(query));
  }, [query]);

  const destination = DESTINATIONS.find((d) => d.id === destId) ?? DESTINATIONS[0];

  const checkCongestion = async () => {
    setLoading(true);
    setResult(null);
    setStepIndex(0);
    const stepTimer = setInterval(() => {
      setStepIndex((prev) => (prev < CALC_STEPS.length - 1 ? prev + 1 : prev));
    }, 400);

    try {
      const params = new URLSearchParams({
        destName: destination.name,
        destLat: String(destination.lat),
        destLng: String(destination.lng),
        routeName: destination.routeName,
      });
      const res = await fetch(`/api/congestion?${params.toString()}`);
      const data = await res.json();
      await new Promise((r) => setTimeout(r, 400 * CALC_STEPS.length));
      setResult(data);
      setTripState({
        destinationId: destination.id,
        destinationName: destination.name,
        destLat: destination.lat,
        destLng: destination.lng,
        congestionIndex: data.congestionIndex,
      });
    } catch (err) {
      console.error(err);
    } finally {
      clearInterval(stepTimer);
      setLoading(false);
      setStepIndex(-1);
    }
  };

  const gaugeColor = (v: number) => (v >= 60 ? "var(--color-danger)" : v >= 30 ? "#c98a00" : "var(--color-primary)");

  const goDiscovery = () => {
    setTripState({
      destinationId: destination.id,
      destinationName: destination.name,
      destLat: destination.lat,
      destLng: destination.lng,
      congestionIndex: undefined,
    });
    router.push("/route-select?mode=discovery");
  };

  return (
    <div>
      <Header />

      <div className="card" style={{ background: "#16241d", color: "#fff" }}>
        <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 4 }}>슬로우-시그널</div>
        <div style={{ fontSize: 12, color: "#a8c9b8", marginBottom: 10 }}>출발 전 15초 혼잡 체크</div>
        <div style={{ fontSize: 12, lineHeight: 1.6 }}>
          출발 전, 목적지 혼잡 여부를 미리 확인하고 필요하면 대안을 제안해드리는 여행 계획
          도우미입니다. 실제 길안내는 평소 쓰시던 내비게이션 앱으로 이어집니다.
        </div>
      </div>

      <div className="quick-menu">
        <span className="chip">실시간 혼잡 분석</span>
        <span className="chip">우회지 추천</span>
        <span className="chip">탄소 절감</span>
      </div>

      <div className="btn-row">
        <a
          className="btn btn-accent"
          href="http://pf.kakao.com/_ESsJX/chat"
          target="_blank"
          rel="noreferrer"
          style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}
        >
          💬 카카오톡 챗봇으로 물어보기
        </a>
      </div>

      <div className="card">
        <input
          type="text"
          placeholder="어디로 가시나요? 목적지를 검색하세요"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          style={{ marginBottom: 12 }}
        />
        <div className="dest-scroll" style={{ padding: 0, margin: "0 -4px 8px" }}>
          {filtered.map((d) => (
            <div
              key={d.id}
              className={"dest-card" + (d.id === destId ? " selected" : "")}
              onClick={() => {
                setDestId(d.id);
                setResult(null);
              }}
            >
              <div className="emoji">{DEST_EMOJI[d.id] ?? "📍"}</div>
              <div className="name">{d.name}</div>
            </div>
          ))}
        </div>
        <div className="scroll-hint">옆으로 넘겨보세요 →</div>

        <button className="btn btn-accent" onClick={checkCongestion} disabled={loading}>
          {loading ? "확인 중..." : "지금 상황 확인하기"}
        </button>
      </div>

      {loading && (
        <div className="card">
          <div className="section-title" style={{ margin: "0 0 10px" }}>혼잡지수 계산 과정</div>
          {CALC_STEPS.map((step, idx) => (
            <div key={step} style={{ display: "flex", alignItems: "center", gap: 8, padding: "6px 0", opacity: idx <= stepIndex ? 1 : 0.3 }}>
              <span style={{ width: 18, height: 18, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, background: idx < stepIndex ? "var(--color-primary)" : idx === stepIndex ? "var(--color-accent)" : "var(--color-surface-2)", color: idx <= stepIndex ? "#fff" : "var(--color-text-muted)" }}>
                {idx < stepIndex ? "✓" : idx === stepIndex ? "●" : ""}
              </span>
              <span style={{ fontSize: 13 }}>{step}</span>
            </div>
          ))}
        </div>
      )}

      {result && (
        <>
          <div className="card">
            <div className="section-title" style={{ margin: "0 0 10px" }}>혼잡지수 계산 결과</div>
            <div className="progress-bar-track" style={{ marginBottom: 6 }}>
              <div className="progress-bar-fill" style={{ width: `${result.congestionIndex}%`, background: gaugeColor(result.congestionIndex) }} />
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 20, fontWeight: 700, color: gaugeColor(result.congestionIndex), marginBottom: 8 }}>
              <span>{result.congestionIndex} / 100</span>
              <span style={{ fontSize: 13, fontWeight: 600, alignSelf: "center" }}>{result.isCongested ? "혼잡" : "보통"}</span>
            </div>
            {result.source === "kakao_mobility" && (
              <div style={{ fontSize: 12, color: "var(--color-text-muted)" }}>
                지금 가면 {Math.round(result.durationSec / 60)}분 (평소보다{" "}
                {Math.max(0, Math.round((result.delayRatio - 1) * 100))}% 더 걸려요)
              </div>
            )}
            {result.source === "highway_corp_fallback" && result.breakdown && (
              <div style={{ fontSize: 11, color: "var(--color-text-muted)" }}>
                보조 참고 데이터(한국도로공사): 실측 +{result.breakdown.exWeight} · 시간대 +{result.breakdown.timeBonus} · 과밀지 +{result.breakdown.hotspot}
              </div>
            )}
            {result.exError && <div style={{ fontSize: 11, color: "var(--color-warning-text)", marginTop: 6 }}>{result.exError}</div>}
          </div>

          {result.isCongested ? (
            <div className="danger-banner">
              <div style={{ fontWeight: 700, color: "var(--color-danger)", marginBottom: 4 }}>⚠️ 지금 가면 막힙니다</div>
              <div style={{ fontSize: 12, color: "var(--color-text-muted)", marginBottom: 12 }}>미리 확인해서 다행이에요</div>
              <button className="btn btn-danger-fill" onClick={() => router.push("/route-select")}>
                우회하기
              </button>
            </div>
          ) : (
            <div className="card" style={{ fontSize: 12, color: "var(--color-text-muted)", textAlign: "center" }}>
              현재 도로가 원활합니다. 편안한 여행 되세요!
            </div>
          )}

          <div className="btn-row">
            <button className="btn btn-outline" onClick={() => router.push("/departure")}>
              🛰️ 실시간 출발 모드로 이동
            </button>
          </div>
        </>
      )}

      <div className="card card-accent" style={{ textAlign: "center" }}>
        <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 4 }}>🍃 오늘은 안 막혀도, 새로운 곳 발견하기</div>
        <div style={{ fontSize: 12, color: "var(--color-text-muted)", marginBottom: 10 }}>
          혼잡 여부와 상관없이 언제든 인구감소지역을 발견하고 방문 보상을 받을 수 있어요
        </div>
        <button className="btn btn-primary" onClick={goDiscovery}>
          이런 곳은 어때요?
        </button>
      </div>

      <div className="api-label">
        사용 API: 카카오모빌리티 자동차 길찾기 API(주) + 한국도로공사 실시간 소통데이터(보조)
      </div>

      <div className="footer-nav">
        <a href="/how-to">❓ 이용안내</a>
        <a href="/my-journey">🏅 내 여정 보기</a>
        <a href="/roadmap">🗺️ 발전방향</a>
      </div>

      <div className="btn-row">
        <a className="btn btn-outline" href="https://open.kakao.com/o/g5VvQyKi" target="_blank" rel="noreferrer">
          👥 지역활성화 참여 커뮤니티(오픈채팅)
        </a>
      </div>
    </div>
  );
}
