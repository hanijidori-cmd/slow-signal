"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import Header from "@/components/Header";
import { DESTINATIONS } from "@/lib/destinations";
import { haversineKm } from "@/lib/haversine";
import { getTripState, setTripState } from "@/lib/clientState";

export default function DeparturePage() {
  const router = useRouter();
  const [permission, setPermission] = useState<"idle" | "granted" | "denied">("idle");
  const [distanceToBranch, setDistanceToBranch] = useState<number | null>(null);
  const [lastUpdate, setLastUpdate] = useState<number | null>(null);
  const triggeredRef = useRef(false);

  const trip = getTripState();
  const destination = DESTINATIONS.find((d) => d.id === trip.destinationId) ?? DESTINATIONS[0];

  useEffect(() => {
    if (permission !== "granted") return;

    const watchId = navigator.geolocation.watchPosition(
      async (pos) => {
        const { latitude, longitude } = pos.coords;
        const dist = haversineKm(latitude, longitude, destination.branchPoint.lat, destination.branchPoint.lng);
        setDistanceToBranch(Math.round(dist * 10) / 10);
        setLastUpdate(Date.now());

        if (dist <= 3 && !triggeredRef.current) {
          triggeredRef.current = true;
          try {
            const params = new URLSearchParams({
              destName: destination.name,
              destLat: String(destination.lat),
              destLng: String(destination.lng),
              routeName: destination.routeName,
              originLat: String(latitude),
              originLng: String(longitude),
            });
            const res = await fetch(`/api/congestion?${params.toString()}`);
            const data = await res.json();
            setTripState({ congestionIndex: data.congestionIndex });
            if (data.isCongested) {
              router.push("/route-select?auto=1");
            }
          } catch (err) {
            console.error(err);
          }
        }
      },
      (err) => console.error("위치 추적 오류:", err),
      { enableHighAccuracy: true, maximumAge: 5000 }
    );

    return () => navigator.geolocation.clearWatch(watchId);
  }, [permission, destination, router]);

  const [secondsAgo, setSecondsAgo] = useState(0);
  useEffect(() => {
    const t = setInterval(() => {
      if (lastUpdate) setSecondsAgo(Math.floor((Date.now() - lastUpdate) / 1000));
    }, 1000);
    return () => clearInterval(t);
  }, [lastUpdate]);

  const requestPermission = () => {
    if (!navigator.geolocation) {
      setPermission("denied");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      () => setPermission("granted"),
      () => setPermission("denied")
    );
  };

  if (permission === "idle") {
    return (
      <div>
        <Header currentStep={0} />
        <div className="card" style={{ textAlign: "center", paddingTop: 30, paddingBottom: 30 }}>
          <div style={{ fontSize: 32, marginBottom: 12 }}>📍</div>
          <div style={{ fontWeight: 700, marginBottom: 8 }}>위치 권한 필요</div>
          <div style={{ fontSize: 12, color: "var(--color-text-muted)", marginBottom: 16 }}>
            실시간 출발 모드는 위치 권한이 필요합니다. 권한을 거부하셔도 수동으로 혼잡도를
            확인할 수 있어요.
          </div>
          <button className="btn btn-accent" onClick={requestPermission} style={{ marginBottom: 8 }}>
            위치 권한 허용하기
          </button>
          <button className="btn btn-outline" onClick={() => router.push("/")}>
            수동으로 혼잡도 확인하기
          </button>
        </div>
        <div className="api-label">사용 API: 브라우저 Geolocation API 실시간 추적</div>
      </div>
    );
  }

  if (permission === "denied") {
    return (
      <div>
        <Header currentStep={0} />
        <div className="card" style={{ textAlign: "center" }}>
          위치 권한이 거부되었습니다.
          <button className="btn btn-primary" style={{ marginTop: 12 }} onClick={() => router.push("/")}>
            수동으로 혼잡도 확인하기
          </button>
        </div>
      </div>
    );
  }

  return (
    <div>
      <Header currentStep={0} />
      <div className="card">
        <div className="live-badge" style={{ marginBottom: 14 }}>
          <span className="live-dot" /> 실시간 위치 감지 중
        </div>
        <div className="grid-2" style={{ marginBottom: 10 }}>
          <div className="stat-box">
            <div className="label">분기점까지</div>
            <div className="value">{distanceToBranch !== null ? `${distanceToBranch}km` : "확인 중..."}</div>
          </div>
          <div className="stat-box">
            <div className="label">마지막 확인</div>
            <div className="value">{lastUpdate ? `${secondsAgo}초 전` : "-"}</div>
          </div>
        </div>
        <div style={{ fontSize: 12, color: "var(--color-text-muted)" }}>
          목적지: {destination.name} · 분기점 반경 3km 진입 시 자동으로 혼잡도를 재확인합니다.
        </div>
      </div>

      <div className="card" style={{ fontSize: 11, color: "var(--color-text-muted)" }}>
        이 기능은 앱이 켜져 있는 동안 실시간으로 작동합니다. 다른 앱으로 전환하면 위치 감지가
        일시 중지될 수 있어요.
      </div>

      <div className="api-label">사용 API: 브라우저 Geolocation API 실시간 추적</div>
    </div>
  );
}
