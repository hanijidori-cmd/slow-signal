"use client";

import { useEffect, useState } from "react";
import Header from "@/components/Header";
import { getCheckInLog, CheckInLogEntry, getTripState } from "@/lib/clientState";

export default function MyJourneyPage() {
  const [log, setLog] = useState<CheckInLogEntry[]>([]);
  const [totalPoints, setTotalPoints] = useState(0);
  const [badges, setBadges] = useState<string[]>([]);

  useEffect(() => {
    setLog(getCheckInLog());
    const trip = getTripState();
    setTotalPoints(trip.totalPoints ?? 0);
    setBadges(trip.badges ?? []);
  }, []);

  const totalCarbon = log.reduce((sum, e) => sum + e.carbonKg, 0);

  return (
    <div>
      <Header />
      <div style={{ padding: "0 16px 12px" }}>
        <div style={{ fontSize: 20, fontWeight: 700 }}>내 여정</div>
        <div style={{ fontSize: 12, color: "var(--color-text-muted)" }}>지금까지의 방문 기록 (익명 세션 기준)</div>
      </div>

      <div className="card">
        <div className="grid-2">
          <div className="stat-box"><div className="label">누적 방문</div><div className="value">{log.length}회</div></div>
          <div className="stat-box"><div className="label">누적 포인트</div><div className="value">{totalPoints}</div></div>
          <div className="stat-box"><div className="label">누적 탄소절감</div><div className="value">{Math.round(totalCarbon * 100) / 100}kg</div></div>
          <div className="stat-box"><div className="label">획득 배지</div><div className="value">{badges.length}개</div></div>
        </div>
      </div>

      {badges.length > 0 && (
        <div className="card">
          <div className="section-title" style={{ margin: "0 0 8px" }}>획득 배지</div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            {badges.map((b) => (
              <span key={b} className="badge badge-accent">🏅 {b}</span>
            ))}
          </div>
        </div>
      )}

      <div className="section-title">방문 기록</div>

      {log.length === 0 && (
        <div className="card" style={{ textAlign: "center", fontSize: 12, color: "var(--color-text-muted)" }}>
          아직 방문 기록이 없어요. 우회지를 방문하고 체크인해보세요!
        </div>
      )}

      {log.map((entry) => (
        <div key={entry.id} className="card">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 6 }}>
            <div>
              <div style={{ fontWeight: 700, fontSize: 14 }}>{entry.candidateTitle}</div>
              <div style={{ fontSize: 11, color: "var(--color-text-muted)" }}>{entry.regionName}</div>
            </div>
            <span className="badge">{entry.entryType === "discovery" ? "🍃 발견" : "⚠️ 우회"}</span>
          </div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap", fontSize: 11, marginBottom: 6 }}>
            <span className="badge badge-accent">🌿 {entry.carbonKg}kg</span>
            <span className="badge badge-accent">🏅 {entry.points}P</span>
            <span className="badge badge-accent">🎫 {entry.couponCode}</span>
          </div>
          <div style={{ fontSize: 10, color: "var(--color-text-muted)" }}>
            {new Date(entry.createdAt).toLocaleString("ko-KR")}
          </div>
        </div>
      ))}

      <div className="btn-row">
        <a className="btn btn-primary" href="/">🏠 홈으로</a>
      </div>
    </div>
  );
}
