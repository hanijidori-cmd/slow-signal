"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Script from "next/script";
import Header from "@/components/Header";
import KakaoMap from "@/components/KakaoMap";
import { DESTINATIONS } from "@/lib/destinations";
import { getTripState, TripState } from "@/lib/clientState";

declare global {
  interface Window {
    Kakao: any;
  }
}

export default function MapPage() {
  const router = useRouter();
  const [trip, setTrip] = useState<TripState | null>(null);
  const kakaoJsKey = process.env.NEXT_PUBLIC_KAKAO_JS_KEY;

  useEffect(() => {
    setTrip(getTripState());
  }, []);

  const initKakaoSdk = () => {
    if (window.Kakao && !window.Kakao.isInitialized() && kakaoJsKey) {
      window.Kakao.init(kakaoJsKey);
    }
  };

  if (!trip) return <div className="card">불러오는 중...</div>;

  const dest = DESTINATIONS.find((d) => d.id === trip.destinationId) ?? DESTINATIONS[0];
  const candidate = trip.selectedCandidate;

  if (!candidate) {
    return (
      <div>
        <Header currentStep={2} />
        <div className="card">
          선택된 우회지가 없습니다.
          <button className="btn btn-outline" style={{ marginTop: 12 }} onClick={() => router.push("/route-select")}>
            경로 선택으로 돌아가기
          </button>
        </div>
      </div>
    );
  }

  const kakaoMapWebLink = `https://map.kakao.com/link/to/${encodeURIComponent(candidate.title)},${candidate.mapY},${candidate.mapX}`;

  const startKakaoNavi = () => {
    try {
      if (window.Kakao?.Navi) {
        window.Kakao.Navi.start({
          name: candidate.title,
          x: candidate.mapX,
          y: candidate.mapY,
          coordType: "wgs84",
        });
        return;
      }
    } catch (err) {
      console.error("카카오내비 실행 실패, 웹으로 대체:", err);
    }
    window.open(kakaoMapWebLink, "_blank");
  };

  return (
    <div>
      <Header currentStep={2} />

      <div style={{ padding: "0 16px" }}>
        <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 2 }}>경로 안내</div>
        <div style={{ fontSize: 12, color: "var(--color-text-muted)", marginBottom: 12 }}>
          {dest.name} → {candidate.title} ({candidate.distanceKm}km)
        </div>
      </div>

      {kakaoJsKey && (
        <Script src="https://developers.kakao.com/sdk/js/kakao.js" strategy="afterInteractive" onLoad={initKakaoSdk} />
      )}

      <KakaoMap
        center={{ lat: dest.lat, lng: dest.lng }}
        markers={[
          { lat: dest.lat, lng: dest.lng, label: dest.name },
          { lat: candidate.mapY, lng: candidate.mapX, label: candidate.title },
        ]}
      />

      <div className="card" style={{ fontSize: 11, color: "var(--color-text-muted)" }}>
        아래 버튼으로 카카오내비를 실행해 안내를 시작하세요. 앱이 설치되어 있지 않으면 카카오맵
        웹으로 열 수 있어요. 실제 길안내는 평소 쓰시던 내비게이션 앱으로 이어집니다.
      </div>

      <div className="btn-row" style={{ flexDirection: "column" }}>
        <button className="btn btn-accent" onClick={startKakaoNavi} style={{ marginBottom: 8 }}>
          🚗 카카오내비로 안내 시작
        </button>
        <a className="btn btn-outline" href={kakaoMapWebLink} target="_blank" rel="noreferrer">
          카카오맵 웹으로 열기
        </a>
      </div>

      <div className="btn-row">
        <button className="btn btn-primary" onClick={() => router.push("/arrival")}>
          이 경유지에 도착했어요 (체크인)
        </button>
      </div>

      <div className="api-label">사용 API: 카카오맵 JavaScript SDK(마커·경로선 표시) · 카카오내비 SDK</div>
    </div>
  );
}
