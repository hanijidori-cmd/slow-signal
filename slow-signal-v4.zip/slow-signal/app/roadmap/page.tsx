import Header from "@/components/Header";

export default function RoadmapPage() {
  const phases = [
    {
      title: "Phase 1 (현재, MVP)",
      items: [
        "KTO OpenAPI 4종(국문관광정보·연관관광지·Odii·이미지) 연동",
        "카카오모빌리티 자동차 길찾기 API 기반 실시간 혼잡 판정",
        "한국도로공사 실시간 소통데이터 보조 검증",
        "카카오맵 SDK, 카카오내비 딥링크, 카카오톡 공유하기",
        "체크인 이력·후기 게시판·오픈채팅 커뮤니티",
      ],
    },
    {
      title: "Phase 2 (사업 제휴 이후)",
      items: [
        "네이티브 앱 전환 + 카카오내비 위 실시간 오버레이 알림 (Android OS 권한 기반)",
        "카카오톡 채널 챗봇 상담 연동",
        "카카오같이가치 공식 캠페인 등록 및 지역화폐 연계 정산",
        "우회지 대상 전남 22개 시군 전역 확대, 목적지 자유검색",
      ],
    },
    {
      title: "Phase 3 (사업화·공공연계)",
      items: [
        "지자체 정책 의사결정용 '남도 트래픽 대시보드' B2G 제공",
        "렌터카·여행사 전용 SDK 배포 (B2B)",
        "카카오 ESG 공식 상생사례 등재 및 글로벌 소도시 확장",
      ],
    },
  ];

  return (
    <div>
      <Header />
      <div style={{ padding: "0 16px 12px" }}>
        <div style={{ fontSize: 20, fontWeight: 700 }}>발전 방향</div>
      </div>
      {phases.map((phase) => (
        <div className="card" key={phase.title}>
          <div style={{ fontWeight: 700, marginBottom: 8 }}>{phase.title}</div>
          <ul style={{ margin: 0, paddingLeft: 18, fontSize: 13, color: "var(--color-text-muted)" }}>
            {phase.items.map((item) => (
              <li key={item} style={{ marginBottom: 4 }}>{item}</li>
            ))}
          </ul>
        </div>
      ))}
      <div className="api-label">
        Phase 2·3 항목은 현재 개인 개발자 권한으로는 사용할 수 없는 사업 제휴형 기능입니다.
      </div>
    </div>
  );
}
