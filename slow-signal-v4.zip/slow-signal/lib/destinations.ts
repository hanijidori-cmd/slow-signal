export type Destination = {
  id: string;
  name: string;
  keyword: string;
  lat: number;
  lng: number;
  routeName: string; // 한국도로공사 API routeName 필터링용
  // 실시간 위치감지 모드에서 "마지막으로 우회 가능한 분기점" 근사 좌표
  branchPoint: { lat: number; lng: number };
};

export const DESTINATIONS: Destination[] = [
  {
    id: "yeosu-odongdo",
    name: "여수 오동도",
    keyword: "오동도",
    lat: 34.7382,
    lng: 127.7594,
    routeName: "남해선",
    branchPoint: { lat: 34.9506, lng: 127.5089 }, // 순천IC 인근
  },
  {
    id: "suncheon-bay",
    name: "순천만습지",
    keyword: "순천만습지",
    lat: 34.8763,
    lng: 127.5219,
    routeName: "순천완주선",
    branchPoint: { lat: 34.9284, lng: 127.4419 }, // 순천JC 인근
  },
  {
    id: "damyang-juknokwon",
    name: "담양 죽녹원",
    keyword: "죽녹원",
    lat: 35.3167,
    lng: 126.9886,
    routeName: "호남선",
    branchPoint: { lat: 35.25, lng: 126.95 },
  },
  {
    id: "wando-beach",
    name: "완도 명사십리해변",
    keyword: "명사십리해변",
    lat: 34.3108,
    lng: 126.755,
    routeName: "고금대교",
    branchPoint: { lat: 34.45, lng: 126.7 },
  },
  {
    id: "mokpo-yudalsan",
    name: "목포 유달산",
    keyword: "유달산",
    lat: 34.7858,
    lng: 126.3708,
    routeName: "무안광주선",
    branchPoint: { lat: 34.85, lng: 126.45 },
  },
  {
    id: "boseong-daehandawon",
    name: "보성 대한다원",
    keyword: "대한다원",
    lat: 34.7714,
    lng: 127.0797,
    routeName: "남해선",
    branchPoint: { lat: 34.85, lng: 127.05 },
  },
];
