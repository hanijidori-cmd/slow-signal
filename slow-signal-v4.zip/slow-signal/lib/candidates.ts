// 전남 인구감소지역 후보 시군 목록
// ⚠️ sigunguCode는 표준 코드표 기준 추정치입니다. 강진군은 특히 미확정 상태라
//    KTO API의 areaCode2 엔드포인트로 실제 값을 재확인 후 교체하세요.
export type CandidateRegion = {
  name: string;
  landmarkName: string;
  areaCode: string;
  sigunguCode: string;
  centerLat: number;
  centerLng: number;
};

export const JEONNAM_AREA_CODE = "38";

export const CANDIDATE_REGIONS: CandidateRegion[] = [
  { name: "보성군", landmarkName: "대한다원", areaCode: "38", sigunguCode: "13", centerLat: 34.7714, centerLng: 127.0797 },
  { name: "고흥군", landmarkName: "우주발사전망대", areaCode: "38", sigunguCode: "9", centerLat: 34.6113, centerLng: 127.2846 },
  { name: "강진군", landmarkName: "다산초당", areaCode: "38", sigunguCode: "13", centerLat: 34.6421, centerLng: 126.7674 }, // TODO: 실제 코드 재확인 필요
  { name: "해남군", landmarkName: "대흥사", areaCode: "38", sigunguCode: "14", centerLat: 34.5734, centerLng: 126.5992 },
  { name: "장흥군", landmarkName: "정남진", areaCode: "38", sigunguCode: "12", centerLat: 34.6813, centerLng: 126.9067 },
];

export const CONGESTED_HOTSPOTS = ["여수", "순천", "오동도", "순천만"];
