const TRIP_KEY = "slow-signal-trip";
const CHECKIN_LOG_KEY = "slow-signal-checkin-log";
const REVIEWS_KEY = "slow-signal-reviews";

export type TripState = {
  destinationId?: string;
  destinationName?: string;
  destLat?: number;
  destLng?: number;
  congestionIndex?: number;
  selectedCandidate?: {
    contentId: string;
    title: string;
    mapX: number;
    mapY: number;
    distanceKm: number;
    score: number;
    regionName: string;
  };
  badges?: string[];
  totalPoints?: number;
};

export function getTripState(): TripState {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(TRIP_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function setTripState(patch: Partial<TripState>) {
  if (typeof window === "undefined") return;
  const current = getTripState();
  const next = { ...current, ...patch };
  window.localStorage.setItem(TRIP_KEY, JSON.stringify(next));
  return next;
}

// 체크인 이력 (엔티티 대신 localStorage, 로그인 없이 익명 세션 기준)
export type CheckInLogEntry = {
  id: string;
  destinationName: string;
  candidateTitle: string;
  regionName: string;
  distanceKm: number;
  carbonKg: number;
  points: number;
  couponCode: string;
  entryType: "congestion" | "discovery";
  createdAt: string; // ISO
};

export function getCheckInLog(): CheckInLogEntry[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(CHECKIN_LOG_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function appendCheckInLog(entry: CheckInLogEntry) {
  if (typeof window === "undefined") return;
  const log = getCheckInLog();
  log.unshift(entry);
  window.localStorage.setItem(CHECKIN_LOG_KEY, JSON.stringify(log.slice(0, 50)));
}

// 후기 게시판
export type ReviewPost = {
  id: string;
  destinationName: string;
  content: string;
  createdAt: string;
};

export function getReviews(destinationName?: string): ReviewPost[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(REVIEWS_KEY);
    const all: ReviewPost[] = raw ? JSON.parse(raw) : [];
    if (!destinationName) return all;
    return all.filter((r) => r.destinationName === destinationName);
  } catch {
    return [];
  }
}

export function addReview(destinationName: string, content: string) {
  if (typeof window === "undefined") return;
  const all = getReviews();
  const entry: ReviewPost = {
    id: `${Date.now()}`,
    destinationName,
    content: content.slice(0, 200),
    createdAt: new Date().toISOString(),
  };
  all.unshift(entry);
  window.localStorage.setItem(REVIEWS_KEY, JSON.stringify(all.slice(0, 200)));
  return entry;
}
