// 혼잡지수 산출 — 카카오모빌리티 실시간 소요시간(주) + 한국도로공사 실측(보조)
// 하이브리드 모델

export const BASELINE_SPEED_KMH = 75;
export const CONGESTION_THRESHOLD_RATIO = 1.15;

export type ExVdsRecord = {
  routeNo?: string;
  routeName?: string;
  grade?: string;
  speed?: string;
  conzoneName?: string;
};

// 카카오모빌리티 duration(초)/distance(m) 기반 혼잡지수
export function congestionFromKakaoDuration(durationSec: number, distanceM: number) {
  const distanceKm = distanceM / 1000;
  const baselineSec = (distanceKm / BASELINE_SPEED_KMH) * 3600;
  const delayRatio = baselineSec > 0 ? durationSec / baselineSec : 1;
  const congestionIndex = Math.min(
    100,
    Math.max(0, Math.round((delayRatio / CONGESTION_THRESHOLD_RATIO) * 60))
  );
  return { delayRatio, congestionIndex, baselineSec };
}

// 도로공사 데이터만으로 계산하는 보조/대체 로직 (카카오 API 실패시 fallback)
export function congestionFromExData(records: ExVdsRecord[]): number {
  if (!records || records.length === 0) return 0;
  let weight = 0;
  for (const r of records) {
    const grade = Number(r.grade);
    if (grade === 3) weight = Math.max(weight, 50);
    else if (grade === 2) weight = Math.max(weight, 25);
  }
  return weight;
}

export function timeOfDayBonus(date: Date = new Date()): number {
  const day = date.getDay();
  const hour = date.getHours();
  const isWeekend = day === 0 || day === 6;
  const isPeakHour = hour >= 10 && hour < 16;
  return isWeekend || isPeakHour ? 30 : 0;
}

export function hotspotBonus(destinationName: string, hotspots: string[]): number {
  return hotspots.some((h) => destinationName.includes(h)) ? 20 : 0;
}

export function fallbackCongestionIndex(params: {
  exWeight: number;
  timeBonus: number;
  hotspot: number;
}): number {
  const total = params.exWeight + params.timeBonus + params.hotspot;
  return Math.min(100, total);
}
