# 슬로우-시그널 (Slow-Signal) v2

2026 한국관광공사X카카오 관광데이터 활용 공모전 — 웹·앱 개발 부문 제출용

Base44 유료 결제 없이, 무료로 배포 가능한 순수 Next.js 코드입니다.

## 실행 전 준비

`.env.local` 파일을 프로젝트 루트에 만들고 `.env.example`의 값을 그대로 복사하세요.
(4개 키 전부 이미 발급받으신 실제 값이 채워져 있습니다)

## 로컬 실행

```bash
npm install
npm run dev
```

## 배포 (Vercel, 무료)

1. 기존 GitHub 저장소(hanijidori-cmd/slow-signal)의 내용을 이 폴더 내용으로
   교체(또는 새 저장소 생성) 후 push
2. https://vercel.com 에서 그 저장소를 Import
3. Environment Variables에 `.env.example`의 4개 키 그대로 등록
4. Deploy → 몇 분 후 실제 URL 생성
5. 카카오 개발자 콘솔(https://developers.kakao.com/console/app/1438804/config/platform-key)
   Web 플랫폼에 배포된 도메인 등록 — 안 하면 지도가 안 뜹니다

## 화면 구성

| 경로 | 화면 | 비고 |
|---|---|---|
| `/` | 홈 — 검색+6개 프리셋, 혼잡분석, 새로운 곳 발견하기 | |
| `/departure` | 실시간 출발 모드 — GPS 분기점 감지 | 위치 권한 필요 |
| `/route-select` | 우회지 추천 (20km 필터 적용됨) | `?mode=discovery`로 발견모드 |
| `/map` | 카카오맵 SDK + 카카오내비 실행 | |
| `/poi/[contentId]` | 경유지 상세 + Odii 오디오/TTS + 후기 | |
| `/arrival` | 도착 보상 + 쿠폰 + 후기작성 + 체크인이력 저장 | |
| `/how-to` | 이용안내 (혼잡판정·추천기준·보상·한계 설명) | |
| `/roadmap` | 발전방향 Phase 2/3 | |

## 사용 API 4종

1. KTO KorService2 (areaBasedList2, detailCommon2, detailIntro2, detailImage2)
2. KTO TarRlteTarService1 (searchKeyword1, 연관카테고리)
3. KTO Odii (themeLocationBasedList, 오디오가이드 — 필드명 실제 호출로 검증 필요)
4. 카카오모빌리티 자동차 길찾기 API (주 혼잡판정) + 한국도로공사 실시간 소통데이터(보조/fallback)
5. 카카오맵 JS SDK, 카카오내비 SDK, 카카오톡 공유하기

## 알려진 제약 (기능설명서 작성 시 참고)

- 체크인 이력·후기는 localStorage 기반입니다 (로그인 없는 익명 세션 원칙 유지,
  실제 서버 DB는 아님 — 브라우저/기기가 바뀌면 이력이 초기화됩니다)
- 강진군 sigunguCode는 표준 코드표 추정치입니다 (`lib/candidates.ts` 참고, 재확인 권장)
- Odii API 필드명은 실제 호출 테스트 후 `app/api/poi/[contentId]/route.ts`의
  audioGuide 파싱 로직을 조정해야 할 수 있습니다
- 카카오모빌리티 API가 401/403을 반환하면 한국도로공사 데이터로 자동 전환됩니다
  (developers.kakaomobility.com에서 권한 신청 필요할 수 있음)
- 카카오톡 채널 챗봇 상담은 미구현 (발전방향 Phase 2로 명시)
